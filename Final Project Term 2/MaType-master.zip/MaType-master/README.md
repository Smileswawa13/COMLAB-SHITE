MaType
======

It's a game where you type words falling from the top of the screen to the bottom. Works with Python 2 and 3.

Licensed under the GNU GPLv3.

Run `python game.py` to start the game.

Demo
====
![Demo](demo.png)
