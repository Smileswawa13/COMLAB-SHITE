from .kezmenu import KezMenu, runTests
from .kezmenu import __version__, __description__
