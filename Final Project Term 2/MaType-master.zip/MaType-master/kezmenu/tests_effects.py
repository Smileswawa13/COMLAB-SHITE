# -*- coding: utf-8 -*-

import doctest

doctest.testfile("docs/EFFECTS.txt", optionflags=doctest.ELLIPSIS|doctest.NORMALIZE_WHITESPACE)